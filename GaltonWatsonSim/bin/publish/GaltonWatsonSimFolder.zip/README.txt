The setup should take around 5 minutes:
1) Double-click on "setup" to install any required files
2) Double-click on "GaltonWatsonSim.exe" (it should have the type "Application" and file size ~ 147 KB)

-- John Blake
Last Modified 5/1/2023 3:44PM